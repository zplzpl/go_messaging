package logger

import "go.uber.org/zap/zapcore"

type Entry = zapcore.Entry
